package br.com.fiap.fintech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GtandeFinaleFintechApplication {

	public static void main(String[] args) {
		SpringApplication.run(GtandeFinaleFintechApplication.class, args);
	}

}
